﻿using $ext_safeprojectname$.Application.Assemblies;
using $ext_safeprojectname$.Domain.Assemblies;
using $ext_safeprojectname$.Insfrastructure.Utilities.Assemblies;
using System.Reflection;
namespace $ext_safeprojectname$.Extensions
{
    public static class ApiAssemblyExtensions
    {
        public static Assembly[] GetLibrariesAssemblies()
        {
            var application = ApplicationAssemblyExtension.GetApplicationAssembly();
            var domain = DomainAssemblyExtension.GetDomainAssembly();
            var insfrastructure = InsfrastructureAssemblyExtension.GetInsfrastructureAssembly();
            return [application, domain, insfrastructure];
        }
    }
}
