﻿using Microsoft.Extensions.Configuration;
using $ext_safeprojectname$.Insfrastructure.Utilities.Kafka;
using $ext_safeprojectname$.Insfrastructure.Utilities.Outboxes;

namespace $ext_safeprojectname$.Persistence.Cdc.MssqlContext;

public static class MssqlDbContextConnectorExtension
{
    public static async Task AddAllConnectorAsync(IConfiguration configuration)
    {
        await KafkaExtension.AddConnector(configuration,
            SkippedOperation.Delete,
            "Outbox",
            nameof(Outbox));
    }
}
