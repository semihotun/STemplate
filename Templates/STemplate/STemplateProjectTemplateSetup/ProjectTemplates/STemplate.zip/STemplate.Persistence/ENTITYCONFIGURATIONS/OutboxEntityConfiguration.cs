﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using $ext_safeprojectname$.Insfrastructure.Utilities.Outboxes;

namespace $ext_safeprojectname$.Persistence.EntityConfigurations;

public class OutboxEntityConfiguration : IEntityTypeConfiguration<Outbox>
{
    public void Configure(EntityTypeBuilder<Outbox> builder)
    {
        builder.HasKey(x => x.Id);
    }
}
