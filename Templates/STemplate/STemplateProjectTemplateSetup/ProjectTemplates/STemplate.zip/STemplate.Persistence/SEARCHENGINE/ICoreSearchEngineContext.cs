﻿using Nest;
using $ext_safeprojectname$.Domain.SeedWork;

namespace $ext_safeprojectname$.Persistence.SearchEngine;

public interface ICoreSearchEngineContext
{
    ElasticClient Client { get; }
    string IndexName<T>() where T : IElasticEntity;
}
