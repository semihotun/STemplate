﻿using $ext_safeprojectname$.Insfrastructure.Utilities.AdminRole;
using $ext_safeprojectname$.Insfrastructure.Utilities.ServiceBus;
using MassTransit;
namespace $ext_safeprojectname$.Application.Extension
{
    /// <summary>
    ///  Add Consumer Or Producer
    /// </summary>
    public static class AddConsumerOrProducer
    {
        public static void AddPublishers(this IRabbitMqBusFactoryConfigurator cfg)
        {
            cfg.AddDirectProducer<AddAdminRoleIntegrationEvent>();
        }
        public static void AddConsumers(this IRabbitMqBusFactoryConfigurator cfg, IBusRegistrationContext ctx)
        {
        }
    }
}
