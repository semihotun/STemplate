﻿namespace $ext_safeprojectname$.Application.Jobs;
public static class HangFireJobs
{
    /// <summary>
    /// All Create Startup Jobs
    /// </summary>
    public static void AddAllStartupJobs()
    {
    }
}