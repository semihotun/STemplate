﻿namespace $ext_safeprojectname$.Insfrastructure.Utilities.Grid.PagedList
{
    /// <summary>
    /// Grid Property
    /// </summary>
    public class GridPropertyInfo
    {
        public string? PropertyName { get; set; }
        public string? PropertyType { get; set; }
    }
}
