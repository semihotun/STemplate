﻿namespace $ext_safeprojectname$.Insfrastructure.Utilities.MediatorBehaviour.Performance;
/// <summary>
/// performance time model
/// </summary>
public interface IIntervalRequest
{
    public int Interval { get; }
}
