﻿namespace $ext_safeprojectname$.Insfrastructure.Utilities.Ioc
{
    /// <summary>
    /// All Services added to IServiceProvider
    /// </summary>
    public static class ServiceTool
    {
        public static IServiceProvider? ServiceProvider { get; set; }
    }
}
