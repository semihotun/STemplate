﻿namespace $ext_safeprojectname$.Insfrastructure.Utilities.HangFire;
public interface IHangFireJob
{
    Task Process();
}
