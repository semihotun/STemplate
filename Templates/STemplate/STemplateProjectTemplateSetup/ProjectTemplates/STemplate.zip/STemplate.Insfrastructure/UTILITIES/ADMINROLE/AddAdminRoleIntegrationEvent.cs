﻿using $ext_safeprojectname$.Insfrastructure.Utilities.ServiceBus;
namespace $ext_safeprojectname$.Insfrastructure.Utilities.AdminRole
{
    [BusType<AddAdminRoleIntegrationEvent>]
    public class AddAdminRoleIntegrationEvent(string[] roleName) : IMessage
    {
        public string[] RoleName { get; set; } = roleName;
    }
}
