﻿namespace $ext_safeprojectname$.Insfrastructure.Utilities.ServiceBus
{
    /// <summary>
    /// All Integration message interface
    /// </summary>
    public interface IMessage
    {
    }
}
