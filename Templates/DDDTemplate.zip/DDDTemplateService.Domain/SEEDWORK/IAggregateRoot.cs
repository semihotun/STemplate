﻿namespace $ext_safeprojectname$.Domain.SeedWork
{
    /// <summary>
    /// Aggregate Root
    /// </summary>
    public interface IAggregateRoot
    {
    }
}
