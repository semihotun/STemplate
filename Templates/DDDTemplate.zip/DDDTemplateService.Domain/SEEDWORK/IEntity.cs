﻿namespace $ext_safeprojectname$.Domain.SeedWork
{
    public interface IEntity
    {
    }
}
